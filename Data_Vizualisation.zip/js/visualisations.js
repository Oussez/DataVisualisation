

// Line Chart : entrer la donnée nettoyer normal c est a dire [{},{},{}]
export function drawGraphicLifeLevel(data) {
    console.log(data)
    const margin = { top: 20, right: 20, bottom: 50, left: 100 },
        width = 1080 - margin.left - margin.right,
        height = 500 - margin.top - margin.bottom;

    const svg = d3.select("#evolution").append("svg")
        .attr("viewBox", `0 0 ${width + margin.left + margin.right} ${height + margin.top + margin.bottom}`)
        // .attr("width",width+margin.left+margin.right)
        // .attr("height",height+margin.top+margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    // Ajouter le titre
    svg.append("text")
        .attr("x", width / 2)
        .attr("y", 0 - margin.top / 6)
        .attr("text-anchor", "middle")
        .style("font-size", "15px") // Taille de police pour le titre
        .style("text-decoration", "underline")
        .text("Évolution du niveau de vie des habitants du pays ");
    // Convert strings to Date objects for time scale
    const parseTime = d3.timeParse("%Y");

    // Map years to Date objects
    const years = data.map(d => parseTime(d.Année));
    const x = d3.scaleTime()
        .domain(d3.extent(years))
        .range([0, width]);
    const y = d3.scaleLinear()
        .domain([0, d3.max(data, d => d3.max(Object.values(d).slice(1), v => +v))]) // Slice to skip 'Année'
        .range([height, 0]);

    // Define the axes
    const xAxis = d3.axisBottom(x).tickFormat(d3.timeFormat("%Y"));
    const yAxis = d3.axisLeft(y);

    // Append the axes
    svg.append("g")
        .attr("transform", `translate(0, ${height})`)
        .attr("class", "x axis")
        .call(xAxis);

    svg.append("g")
        .attr("class", "y axis")
        .call(yAxis);

    // Color scale for countries
    const colorScale = d3.scaleOrdinal(d3.schemeCategory10);

    // Event listener for the dropdown change
    d3.select("#selector").on("change", function () {
        const selectedCountry = d3.select(this).property("value");
        updateGraph(selectedCountry, data, svg, x, y, colorScale);
    });


    // Initial update for the default selected country
    const defaultCountry = d3.select("#selector").property("value");
    updateGraph(defaultCountry, data, svg, x, y, colorScale);
}

export function updateGraph(selectedCountry, data, svg, x, y, colorScale) {
    // Filter data for the selected country for all years
    const parseTime = d3.timeParse("%Y");
    const countryData = data.map(yearData => { // prend l'anneé et la qualite de vie du pays durant cette année
        return {
            Année: parseTime(yearData.Année),
            Value: +yearData[selectedCountry]
        };
    }).filter(d => !isNaN(d.Value));

    console.log(countryData)

    // Remove any previous lines
    svg.selectAll(".line").remove();

    // Create the line generator
    const line = d3.line()
        .defined(d => !isNaN(d.Value)) // Ensure value is defined and is a number
        .x(d => x(d.Année))
        .y(d => y(d.Value));

    // Draw the line
    svg.append("path")
        .datum(countryData) // Pass the array filtered for the selected country
        .attr("class", "line")
        .attr("fill", "none")
        .attr("stroke", colorScale(selectedCountry))
        .attr("stroke-width", 2)
        .attr("d", line);
}
export function drawDivergenceBarChart(netContribution) {
    const margin = { top: 30, right: 40, bottom: 10, left: 50 },
        width = 900 - margin.left - margin.right, // Largeur réduite
        height = 540 - margin.top - margin.bottom; // Hauteur réduite
    console.log(netContribution)
    const x = d3.scaleLinear()
        .domain([d3.min(Object.values(netContribution)), d3.max(Object.values(netContribution))])
        .rangeRound([margin.left, width - margin.right]);

    const y = d3.scaleBand()
        .domain(Object.keys(netContribution))
        .rangeRound([margin.top, height - margin.bottom])
        .padding(0.1);



    const svg = d3.select('#contribution')
        .append("svg")
        //.attr("viewBox", "0 0 " + (width + margin.left + margin.right) + " " + (height + margin.top + margin.bottom))
        .attr('width', width + margin.left + margin.right) // svg prend tout la largeur
        .attr('height', height + margin.top + margin.bottom)// svg prend toute la longueur
        .append('g')
        .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')
        .style("position", "absolute")
        .style("top", "0")
        .style("left", "0");


    // draw The x axis
    svg.append("g")
        .attr("transform", `translate(0,${height - margin.bottom})`)
        .call(d3.axisBottom(x))
    //draw the y axis si vous voulez l ajouter 
    // svg.append("g")
    //     .attr("transform", `translate(${margin.left},0)`)
    //     .call(d3.axisLeft(y))


    //Ajouter le Titre
    // Ajouter le Titre avec un espacement ajusté
    svg.append("text")
        .attr("x", (width / 2)) // Centre le titre par rapport à la largeur
        .attr("y", margin.top / 4) // Réduire pour rapprocher du graphique
        .attr("text-anchor", "middle")//  le texte est centré horizontalement par rapport au point d'ancrage défini par x
        .style("font-size", "14px") // Taille de police ajustée si nécessaire
        .style("text-decoration", "underline")
        .text("les pays qui contribuent plus qu’ils ne reçoivent au budget de l’UE et inversement en Md £ durant la période 2000 -2020");

    console.log(Object.entries(netContribution))
    console.log(netContribution)
    svg.selectAll("rect")
        .data(Object.entries(netContribution)) // mettre les données sous forme tableau des tableau de key , value
        .enter()
        .append("rect")
        .attr("x", d => x(Math.min(d[1], 0)))
        .attr("y", d => y(d[0]))
        .attr("width", d => Math.abs(x(d[1]) - x(0))) //  console.log("Pays : ",d[0],"voile ",x(d[1])-x(0))return Math.abs(x(d[1]) - x(0))
        .attr("height", y.bandwidth())
        .attr("fill", d => d[1] < 0 ? "red" : "steelblue");

    // Ajustement de la taille de la police des axes et des étiquettes si nécessaire

    svg.selectAll("text.country")
        .data(Object.entries(netContribution))
        .enter()
        .append("text")
        .attr("class", "country")
        .attr("y", d => y(d[0]) + y.bandwidth() / 2) // Centrer le texte dans la bande
        .attr("x", d => d[1] < 0 ? x(d[1]) - 6 : x(d[1]) + 6) // Positionner à gauche ou à droite
        .attr("dy", "0.35em") // Centrer verticalement le texte dans la bande
        .attr("text-anchor", d => d[1] < 0 ? "end" : "start") // Aligner le texte correctement
        .style("font-size", "20px") // Augmenter la taille du texte
        .text(d => d[0]); // Mettre le nom du pays comme texte

    svg.selectAll(".axis text").style("font-size", "10px");
    svg.selectAll(".country").style("font-size", "10px");

}

// Assurez-vous que pib et qualite sont les tableaux de données passés à la fonction drawScatterPlot.

export function drawScatterPlot(pib, qualite) {
    // Préparer les données
    let combinedData = [];
    pib.forEach(pibYear => {
        const year = pibYear.Année;
        const qualiteYear = qualite.find(q => q.Année === year);
        Object.keys(pibYear).forEach(country => {
            if (country !== "Année" && country !== "Total") {
                combinedData.push({
                    country: country,
                    year: year,
                    pib: +pibYear[country],
                    qualiteVie: qualiteYear && qualiteYear[country] ? +qualiteYear[country] : null
                });
            }
        });
    });
    combinedData = combinedData.filter(d => d.qualiteVie != null);
    console.log(combinedData)

    // Configuration du SVG et des marges
    const margin = { top: 30, right: 30, bottom: 30, left: 150 },
        width = 700 - margin.left - margin.right,
        height = 400 - margin.top - margin.bottom;

    const svg = d3.select("#scatter")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    // Créer les échelles
    const x = d3.scaleLinear()
        .domain([0, d3.max(combinedData, d => d.pib)])
        .range([0, width]);

    const y = d3.scaleLinear()
        .domain([0, d3.max(combinedData, d => d.qualiteVie)])
        .range([height, 0]);

    // Ajouter les axes
    svg.append("g")
        .attr("transform", `translate(0, ${height})`)
        .call(d3.axisBottom(x));

    svg.append("g")
        .call(d3.axisLeft(y));

    // Dessiner les points
    svg.selectAll("circle")
        .data(combinedData)
        .enter()
        .append("circle")
        .attr("cx", d => x(d.pib))
        .attr("cy", d => y(d.qualiteVie))
        .attr("r", 3)
        .style("fill", "#69b3a2");

    svg.append("text")
        .attr("x", width / 2)
        .attr("y", 0 - margin.top / 6)
        .attr("text-anchor", "middle")
        .style("font-size", "15px") // Taille de police pour le titre
        .style("text-decoration", "underline")
        .text("La correlation entre Le niveau de vie des habitants d’un pays et le PIB  ");

    svg.append("text")
        .attr("text-anchor", "end")
        .attr("x", width / 2)
        .attr("y", height + margin.bottom - 1) // Positionnement en dessous de l'axe X
        .style("font-size", "13px")
        .style("text-decoration", "underline")
        .text("PIB");

    // Ajouter le titre de l'axe Y
    svg.append("text")
        .attr("text-anchor", "end")
        .attr("transform", "rotate(-90)") // Rotation pour aligner verticalement
        .attr("y", -margin.left + 90) // Positionnement à gauche de l'axe Y
        .attr("x", -height / 2)
        .text("Qualité de vie");


    d3.select("#selectorScatter").on("change", function () {
        const selectedCountry = d3.select(this).property("value");
        updateScatterPlot(selectedCountry, combinedData, x, y, svg);
    });
}

export function updateScatterPlot(selectedCountry, combinedData, x, y, svg) {
    // Filtrer les données pour le pays sélectionné et exclure les entrées 'Total'
    const filteredData = combinedData.filter(d => d.country === selectedCountry && d.country !== 'Total');
    console.log(filteredData)
    // Supprimer les points existants
    svg.selectAll("circle").remove();

    // Ajouter les points pour le pays sélectionné
    svg.selectAll("circle")
        .data(filteredData)
        .enter()
        .append("circle")
        .attr("cx", d => x(d.pib))
        .attr("cy", d => y(d.qualiteVie))
        .attr("r", 5)
        .style("fill", "#69b3a2");
}

export function drawBarChart(data) {
    const positiveData = Object.keys(data).reduce((acc, key) => {
        if (data[key] > 0) {
            acc[key] = data[key];
        }
        return acc;
    }, {});

    const MARGIN = { LEFT: 100, RIGHT: 10, TOP: 10, BOTTOM: 130 };
    const WIDTH = 500 - MARGIN.LEFT - MARGIN.RIGHT;
    const HEIGHT = 400 - MARGIN.TOP - MARGIN.BOTTOM;

    const svg = d3.select("#barChart").append("svg")
        .attr("width", WIDTH + MARGIN.LEFT + MARGIN.RIGHT)
        .attr("height", HEIGHT + MARGIN.TOP + MARGIN.BOTTOM);

    const g = svg.append("g")
        .attr("transform", `translate(${MARGIN.LEFT}, ${MARGIN.TOP})`);

    // Axes labels (switched places)
    g.append("text")
        .attr("class", "y axis-label")
        .attr("x", -(HEIGHT / 2))
        .attr("y", -60)
        .attr("font-size", "20px")
        .attr("text-anchor", "middle")
        .attr("transform", "rotate(-90)")
        .text("The world's tallest buildings");

    g.append("text")
        .attr("class", "x axis-label")
        .attr("x", WIDTH / 2)
        .attr("y", HEIGHT + 110)
        .attr("font-size", "20px")
        .attr("text-anchor", "middle")
        .text("Height (m)");

    // Scales (switched domains and ranges)
    const y = d3.scaleBand()
        .domain(Object.keys(positiveData))
        .range([0, HEIGHT])
        .paddingInner(0.3)
        .paddingOuter(0.2);

    const x = d3.scaleLinear()
        .domain([0, d3.max(Object.values(positiveData))])
        .range([0, WIDTH]);

    // Axis generators (switched calls)
    const yAxisCall = d3.axisLeft(y);
    g.append("g")
        .attr("class", "y axis")
        .call(yAxisCall);

    const xAxisCall = d3.axisBottom(x)
        .ticks(3)
        .tickFormat(d => d + "m");
    g.append("g")
        .attr("class", "x axis")
        .attr("transform", `translate(0, ${HEIGHT})`)
        .call(xAxisCall);

    // Bars (switched coordinates and dimensions)
    g.selectAll("rect")
        .data(Object.entries(positiveData))
        .enter()
        .append("rect")
        .attr("y", d => y(d[0]))
        .attr("x", 0) // Bars start at x=0
        .attr("width", d => x(d[1]))
        .attr("height", y.bandwidth())
        .attr("fill", "grey");
}
export function drawBarChart2(data) {
    const positiveData = Object.keys(data).reduce((acc, key) => {
        if (data[key] > 0) {
            acc[key] = data[key];
        }
        return acc;
    }, {});

    const MARGIN = { LEFT: 150 , RIGHT: 20, TOP: 40, BOTTOM: 30 };
    const WIDTH = 600 - MARGIN.LEFT - MARGIN.RIGHT;
    const HEIGHT = 300 - MARGIN.TOP - MARGIN.BOTTOM;

    const svg = d3.select("#barChart").append("svg")
        .attr("width", WIDTH + MARGIN.LEFT + MARGIN.RIGHT)
        .attr("height", HEIGHT + MARGIN.TOP + MARGIN.BOTTOM);

    const g = svg.append("g")
        .attr("transform", `translate(${MARGIN.LEFT}, ${MARGIN.TOP})`);

    const y = d3.scaleBand()
        .domain(Object.keys(positiveData).sort((a, b) => positiveData[b] - positiveData[a])) // Sort keys by value
        .range([0, HEIGHT])
        .padding(0.1);

    const x = d3.scaleLinear()
        .domain([0, d3.max(Object.values(positiveData))])
        .range([0, WIDTH]);

    // Bars
    g.selectAll(".bar")
        .data(Object.entries(positiveData))
        .enter()
        .append("rect")
        .attr("class", "bar")
        .attr("y", d => y(d[0]))
        .attr("height", y.bandwidth())
        .attr("x", 0)
        .attr("width", d => x(d[1]))
        .attr("fill", "steelblue");

    // Labels for the bar values
    g.selectAll(".value-label")
        .data(Object.entries(positiveData))
        .enter()
        .append("text")
        .attr("class", "value-label")
        .attr("x", d => x(d[1]) + 3)
        .attr("y", d => y(d[0]) + y.bandwidth() / 2)
        .text(d => d[1].toFixed(2))
        .attr("text-anchor", "start")
        .attr("alignment-baseline", "middle");

    // Category labels
    g.selectAll(".category-label")
        .data(Object.keys(positiveData))
        .enter()
        .append("text")
        .attr("class", "category-label")
        .attr("x", -5) // Offset from the left edge of the bar
        .attr("y", d => y(d) + y.bandwidth() / 2)
        .text(d => d)
        .attr("text-anchor", "end")
        .attr("alignment-baseline", "middle");

    svg.append("text")
        .attr("x", WIDTH / 2 + MARGIN.LEFT)
        .attr("y", MARGIN.TOP / 1.5)
        .attr("text-anchor", "middle")
        .style("font-size", "15px")
        .style("text-decoration", "underline")
        .text("Contribution nette positif en Md £")

}

export function drawSlopeGraph(data) {

    let startYear = data[0]["Année"];
    let endYear = data[data.length - 1]["Année"];
    let countriesData = data.map(d => {
        let entry = { Année: d["Année"] };
        Object.keys(d).forEach(key => {
            if (key !== "Année") {
                entry[key] = +d[key]; // Convertir en nombre
            }
        });
        return entry;
    });

    // Sélectionner les données pour les années de début et de fin
    let startData = countriesData.find(d => d["Année"] == startYear);
    let endData = countriesData.find(d => d["Année"] == endYear);

    let transformedData = Object.keys(startData).filter(k => k !== "Année").map(country => {
        return { country, startValue: startData[country], endValue: endData[country] };
    });

    // Configurer le SVG
    let svg = d3.select("slopeGraphe");
    let margin = { top: 20, right: 20, bottom: 30, left: 40 },
        width = +svg.attr("width") - margin.left - margin.right,
        height = +svg.attr("height") - margin.top - margin.bottom,
        g = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    // Échelles
    let x = d3.scaleBand().rangeRound([0, width]).padding(0.1)
        .domain([startYear, endYear]);

    let y = d3.scaleLinear().rangeRound([height, 0])
        .domain([
            d3.min(transformedData, d => Math.min(d.startValue, d.endValue)),
            d3.max(transformedData, d => Math.max(d.startValue, d.endValue))
        ]);

    // Dessiner les lignes
    g.selectAll(".line")
        .data(transformedData)
        .enter().append("line")
        .attr("x1", x(startYear))
        .attr("x2", x(endYear))
        .attr("y1", d => y(d.startValue))
        .attr("y2", d => y(d.endValue))
        .attr("stroke", "steelblue")
        .attr("stroke-width", 1.5);

    // Ajouter des étiquettes
    g.selectAll(".label")
        .data(transformedData)
        .enter().append("text")
        .attr("x", d => x(endYear) + 5)
        .attr("y", d => y(d.endValue))
        .attr("dy", "0.35em")
        .text(d => d.country + ": " + d.endValue);

    // Axes
    g.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(x));

    g.append("g")
        .call(d3.axisLeft(y));
}



// Fonction pour dessiner un bullet graph pour le niveau de vie
export function drawBulletGraph(data) {
    // Configuration initiale du graphique
    const margin = { top: 5, right: 40, bottom: 20, left: 120 },
        width = 960 - margin.left - margin.right,
        height = 50 - margin.top - margin.bottom;

    // Création des échelles - exemple basé sur la valeur médiane
    const xScale = d3.scaleLinear()
        .domain([0, d3.max(data, d => d.medianValue)]) // Remplacer 'medianValue' par la valeur médiane appropriée
        .range([0, width]);

    // Sélectionner l'élément du DOM où le graphique sera placé
    const chart = d3.select("#bulletChart")
        .selectAll("g")
        .data(data)
        .enter().append("g")
        .attr("transform", (d, i) => `translate(${margin.left},${i * height + margin.top})`);

    // Dessiner la barre de fond
    chart.append("rect")
        .attr("class", "background")
        .attr("width", width)
        .attr("height", height - margin.top)
        .attr("fill", "#eee");

    // Dessiner la barre de premier plan
    chart.append("rect")
        .attr("class", "foreground")
        .attr("width", d => xScale(d.currentValue)) // Remplacer 'currentValue' par la valeur actuelle appropriée
        .attr("height", height - margin.top)
        .attr("fill", "#555");

    // Dessiner la marque de l'objectif
    chart.append("line")
        .attr("class", "target")
        .attr("x1", d => xScale(d.targetValue)) // Remplacer 'targetValue' par la valeur cible
        .attr("x2", d => xScale(d.targetValue))
        .attr("y1", height / 4)
        .attr("y2", height * 3 / 4)
        .attr("stroke", "#f00");

    // Ajouter des étiquettes de valeur si nécessaire
}
//drawScatterPlotLifeLevelContribution
// salah 
export function drawScatterPlotLifeLevelContribution(netContribution, qualite) {
    const averageQualityOfLife = calculateAverageQualityOfLife(qualite);

    // Convertir les valeurs de netContribution en nombres décimaux
    const netContributionNumeric = {};
    Object.entries(netContribution).forEach(([country, value]) => {
        netContributionNumeric[country] = parseFloat(value);
    });

    // Définir une palette de couleurs
    const colorScale = d3.scaleOrdinal(d3.schemeCategory10);

    // Configuration du SVG et des marges
    const margin = { top: 30, right: 150, bottom: 30, left: 150 },
        width = 700 - margin.left - margin.right,
        height = 400 - margin.top - margin.bottom;

    const svg = d3.select("#scatterPloteNv")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

        svg.append("text")
        .attr("x", (width / 2))
        .attr("y", 0 - (margin.top / 2))
        .attr("text-anchor", "middle")
        .style("font-size", "16px")
        .style("text-decoration", "underline")
        .text("le niveau de vie en regard de la contribution nette en Md £");


    // Créer les échelles
    const x = d3.scaleLinear()
        .domain([d3.min(Object.values(netContributionNumeric)), d3.max(Object.values(netContributionNumeric))])
        .range([0, width]);

    const y = d3.scaleLinear()
        .domain([d3.min(Object.values(averageQualityOfLife)), d3.max(Object.values(averageQualityOfLife))])
        .range([height, 0]);

    // Dessiner les points
    svg.selectAll("circle")
        .data(Object.entries(netContributionNumeric))
        .enter()
        .append("circle")
        .attr("cx", d => x(d[1]))
        .attr("cy", d => y(averageQualityOfLife[d[0]]))
        .attr("r", 5)
        .style("fill", d => colorScale(d[0])) // Associer chaque pays à une couleur
        .style("opacity", 0.7);

    // Ajouter la légende des couleurs à droite
    const legend = svg.selectAll(".legend")
        .data(Object.keys(netContributionNumeric))
        .enter().append("g")
        .attr("class", "legend")
        .attr("transform", (d, i) => `translate(${width + 10},${i * 14})`);

    legend.append("rect")
        .attr("width", 18)
        .attr("height", 18)
        .style("fill", d => colorScale(d));

    legend.append("text")
        .attr("x", 22)
        .attr("y", 9)
        .attr("dy", ".35em")
        .style("text-anchor", "start")
        .text(d => d);

    // Ajouter les axes
    svg.append("g")
        .attr("transform", `translate(0, ${height})`)
        .call(d3.axisBottom(x))
        .append("text")
        .attr("x", width)
        .attr("y", -10)
        .attr("dy", "0.71em")
        .attr("fill", "#000")
        .attr("text-anchor", "end")
        .style("font-size", "12px")
        .text("Contribution nette");

    svg.append("g")
        .call(d3.axisLeft(y))
        .append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 6)
        .attr("dy", "0.71em")
        .attr("fill", "#000")
        .text("Qualité de vie moyenne")
        .style("font-size", "16px")
}


// Fonction pour calculer la qualité de vie moyenne par pays sur toutes les années
function calculateAverageQualityOfLife(qualiteVie) {
    // Initialiser un objet pour stocker la somme et le nombre d'années par pays
    const sumByCountry = {};
    const countByCountry = {};

    // Parcourir les données de qualité de vie
    qualiteVie.forEach(year => {
        Object.keys(year).forEach(country => {
            if (country !== "Année") {
                // Ajouter la qualité de vie au total par pays
                sumByCountry[country] = (sumByCountry[country] || 0) + parseFloat(year[country]);
                // Incrémenter le compteur d'années par pays
                countByCountry[country] = (countByCountry[country] || 0) + 1;
            }
        });
    });

    // Calculer la qualité de vie moyenne par pays avec deux nombres après la virgule
    const averageQualityOfLife = {};
    Object.keys(sumByCountry).forEach(country => {
        averageQualityOfLife[country] = parseFloat((sumByCountry[country] / countByCountry[country]).toFixed(2));
    });

    return averageQualityOfLife;
}



