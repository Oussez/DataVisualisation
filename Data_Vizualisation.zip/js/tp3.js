import { loadData } from "./calculations.js"



document.addEventListener("DOMContentLoaded", loadData);
