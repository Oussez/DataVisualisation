
import { drawBarChart, drawBarChart2, drawBulletGraph, drawDivergenceBarChart,  drawGraphicLifeLevel, drawScatterPlot, drawScatterPlotLifeLevelContribution } from "./visualisations.js"

let data = []
let budgetRecuData = []
let contributionBudgetData = []
let niveauDeVieData = []
let pibParHabitantData = []

const budgetRecuPath = "../data/EU.BudgetRecu.csv"
const contributionPath = "../data/EU.ContributionBudget.csv"
const niveauDeViePath = "../data/EU.NiveauDeVie.csv"
const pibParHabitantPath = "../data/EU.PIBparHabitant.csv"
export function loadData() {
    return Promise.all([
        d3.dsv(";", budgetRecuPath),
        d3.dsv(";", contributionPath),
        d3.dsv(";", niveauDeViePath),
        d3.dsv(";", pibParHabitantPath),
    ]).then((values) => {
        console.log("tet")
        budgetRecuData = cleanData(values[0])
        contributionBudgetData = cleanData(values[1])
        niveauDeVieData = cleanData(values[2])
        pibParHabitantData = cleanData(values[3])
        console.log(niveauDeVieData)
        drawBulletGraph(niveauDeVieData)
        drawGraphicLifeLevel(niveauDeVieData)
        const netContribution = calculateNetContribution(budgetRecuData, contributionBudgetData);
        console.log(netContribution)
        drawDivergenceBarChart(netContribution)
        drawScatterPlot(pibParHabitantData, niveauDeVieData)
        drawBarChart2(netContribution)
        console.log("ehhh")
        drawScatterPlotLifeLevelContribution(netContribution,niveauDeVieData)
    }).catch(error => console.log(error))
}

export function cleanData(data) { // toujours en nettoye un tableau d'objet  , toujours les colonnes sont nettoyés

    // Filtrer les objets qui ont une clé 'Année' avec une valeur non nulle et définie
    console.log(data)
    const filteredData = data.filter(row => row.hasOwnProperty('Année') && row['Année']);
    console.log(filteredData)
    filteredData.forEach((row) => {
        Object.keys(row).forEach(key => {
            if (row["Année"] === 0) {
                delete data[row]
            }
            let cleanedValue = row[key].replace(/\$/g, "").replace(',', '.').trim();
            if (key != "Année") {
                cleanedValue = parseFloat(cleanedValue) || 0;
            }
            row[key] = cleanedValue

            if (row[key] === "") { // si on a pas l'année on supprime toute la ligne
                console.log("Empty value for key ", key, 'in row:', row[key]);

                delete row[key]
            }
        });
    })
    console.log(filteredData)

    return filteredData;
}

export function calculateNetContribution(receivedData, contributionData) {// il me faut a chaque moment le row De chaque data
    console.log(receivedData)
    console.log(contributionData)
    let netContribution = {}// Object 
    let counts = {};// Object    {France: 12}
    for (let i = 0; i < receivedData.length; i++) { // prendre chaque dans LES DEUX TABLEAU parcequ'on va les utiliser pour calculer diff
        let contributedRow = contributionData[i]
        let receivedRow = receivedData[i]

        // wehda fihoum 
        for (const key in receivedRow) {
            if (key != "Année" && key != "Total") {
                let difference = contributedRow[key] - receivedRow[key]
                if (!isNaN(difference) && difference != null) {
                    netContribution[key] = (netContribution[key] || 0) + difference;
                    counts[key] = (counts[key] || 0) + 1;
                }
            }
        }
    }

    // convertir somme to moyenne
    // console.log(netContribution)
    // for (const key in netContribution) {
    //     netContribution[key] = netContribution[key] / counts[key]
    // }

    // sort by descending order

    const sortedNetContributions = Object.fromEntries(
        Object.entries(netContribution).sort(([, a], [, b]) => b - a)
    );

    console.log(sortedNetContributions)
    return sortedNetContributions;
}


export function getAllYears(data) {
    return data.map(entry => entry["Année"]);
}